import pygame
import socket
import json
import threading

# Set up the game window
pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Uno Game")

# Global game state and player ID
game_state = None
player_id = None

# Function to draw text
def draw_text(text, x, y, size=36, color=(0, 0, 0)):
    font = pygame.font.Font(None, size)
    surface = font.render(text, True, color)
    screen.blit(surface, (x, y))

# Function to get color
def get_color(color_name):
    colors = {
        'red': (255, 0, 0),
        'green': (0, 255, 0),
        'blue': (0, 0, 255),
        'yellow': (255, 255, 0),
    }
    return colors.get(color_name, (255, 255, 255))

# Function to handle incoming data from the server
def handle_server_data(client_socket):
    global game_state
    global player_id
    while True:
        data = receive_data(client_socket)
        if not data:
            break
        received_data = json.loads(data)
        if 'player_id' in received_data:
            player_id = received_data['player_id']
        if 'game_state' in received_data:
            game_state = received_data['game_state']

# Function to send data to the server
def send_data(client_socket, data):
    try:
        json_data = json.dumps(data)
        length = len(json_data)
        client_socket.sendall(length.to_bytes(4, 'big') + json_data.encode())
    except Exception as e:
        print(f"Error sending data: {e}")

# Function to receive data from the server
def receive_data(client_socket):
    try:
        raw_length = client_socket.recv(4)
        if not raw_length:
            return None
        length = int.from_bytes(raw_length, 'big')
        data = client_socket.recv(length)
        while len(data) < length:
            data += client_socket.recv(length - len(data))
        return data.decode()
    except Exception as e:
        print(f"Error receiving data: {e}")
        return None

# Function to connect to the server
def connect_to_server():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 12345))
    threading.Thread(target=handle_server_data, args=(client_socket,)).start()
    return client_socket

# Connect to the server
client_socket = connect_to_server()

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if game_state and game_state['players'][game_state['current_player']]['name'] == f'Player {player_id}':
                # Handle mouse clicks to play cards or draw cards
                x, y = pygame.mouse.get_pos()
                current_player = game_state['players'][game_state['current_player']]
                top_card = game_state['discard_pile'][-1]

                # Check if the draw pile is clicked
                if 650 <= x <= 750 and 400 <= y <= 450:
                    if game_state['deck']:
                        current_player['hand'].append(game_state['deck'].pop())
                        game_state['current_player'] = (game_state['current_player'] + 1) % len(game_state['players'])
                        send_data(client_socket, {'game_state': game_state})

                # Play a card
                hand_x_start = 100
                hand_y_start = 500
                card_width = 50
                card_height = 100
                for index, card in enumerate(current_player['hand']):
                    card_x = hand_x_start + index * (card_width + 10)
                    card_y = hand_y_start
                    if card_x <= x <= card_x + card_width and card_y <= y <= card_y + card_height:
                        if card['color'] == top_card['color'] or card['value'] == top_card['value']:
                            game_state['discard_pile'].append(current_player['hand'].pop(index))
                            if card['value'] == 'reverse':
                                game_state['players'].reverse()
                            elif card['value'] == 'skip':
                                game_state['current_player'] = (game_state['current_player'] + 1) % len(game_state['players'])
                            elif card['value'] == 'draw two':
                                next_player = (game_state['current_player'] + 1) % len(game_state['players'])
                                for _ in range(2):
                                    game_state['players'][next_player]['hand'].append(game_state['deck'].pop())
                            game_state['current_player'] = (game_state['current_player'] + 1) % len(game_state['players'])
                            if len(current_player['hand']) == 0:
                                print(f"{current_player['name']} wins!")
                                running = False
                            send_data(client_socket, {'game_state': game_state})
                        break

    # Draw the game state
    screen.fill((0, 128, 0))  # Green background
    if game_state:
        # Draw the discard pile on the right side
        if game_state['discard_pile']:
            top_card = game_state['discard_pile'][-1]
            card_color = get_color(top_card['color'])
            pygame.draw.rect(screen, card_color, (650, 250, 100, 150))
            draw_text(f"{top_card['color']} {top_card['value']}", 655, 300, 24, (0, 0, 0))

        # Draw the draw deck beneath the discard pile
        pygame.draw.rect(screen, (255, 255, 255), (650, 400, 100, 50))
        draw_text("Draw", 675, 410, 24, (0, 0, 0))

        # Draw the players' hands
        hand_x_start = 100
        hand_y_start = 500
        card_width = 50
        card_height = 100
        for index, card in enumerate(game_state['players'][game_state['current_player']]['hand']):
            card_x = hand_x_start + index * (card_width + 10)
            card_y = hand_y_start
            card_color = get_color(card['color'])
            pygame.draw.rect(screen, card_color, (card_x, card_y, card_width, card_height))
            draw_text(f"{card['value']}", card_x + 10, card_y + 40, 24, (0, 0, 0))

        # Draw other players' hands (as hidden cards)
        for i, player in enumerate(game_state['players']):
            if i != game_state['current_player']:
                for j in range(len(player['hand'])):
                    pygame.draw.rect(screen, (200, 200, 200), (hand_x_start + j * (card_width + 10), 50 + i * 120, card_width, card_height))

        # Draw player labels
        for i, player in enumerate(game_state['players']):
            if i == game_state['current_player']:
                color = (255, 0, 0)  # Red for the current player
            else:
                color = (255, 255, 255)  # White for other players
            draw_text(player['name'], 10, 50 + i * 120, 36, color)

    pygame.display.flip()

pygame.quit()
