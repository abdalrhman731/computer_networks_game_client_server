import pygame
import random
import socket
import threading

# Set up the game window
pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Uno Game")

# Set up the game state
game_state = {
    'deck': [],
    'players': [{'name': 'Player 1', 'hand': []}, {'name': 'Player 2', 'hand': []}, {'name': 'Player 3', 'hand': []}, {'name': 'Player 4', 'hand': []}],
    'current_player': 0,
    'discard_pile': []
}

# Set up the deck
colors = ['red', 'green', 'blue', 'yellow']
values = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'reverse', 'skip', 'draw two']
for color in colors:
    for value in values:
        game_state['deck'].append({'color': color, 'value': value})
random.shuffle(game_state['deck'])

# Deal the cards
for player in game_state['players']:
    for _ in range(7):
        player['hand'].append(game_state['deck'].pop())

# Start the game with one card on the discard pile
game_state['discard_pile'].append(game_state['deck'].pop())

def handle_client_connection(client_socket):
    while True:
        try:
            data = client_socket.recv(1024)
            if not data:
                break
            # Handle received data
        except:
            break
    client_socket.close()

def server_thread():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 12345))
    server_socket.listen(1)
    while True:
        client_socket, addr = server_socket.accept()
        client_handler = threading.Thread(target=handle_client_connection, args=(client_socket,))
        client_handler.start()

def client_thread():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', 12345))
    while True:
        # Send and receive data
        pass

# Start the server and client threads
server = threading.Thread(target=server_thread)
server.daemon = True
server.start()

client = threading.Thread(target=client_thread)
client.daemon = True
client.start()

# Helper function to draw text
def draw_text(text, x, y, size=36, color=(0, 0, 0)):
    font = pygame.font.Font(None, size)
    surface = font.render(text, True, color)
    screen.blit(surface, (x, y))

# Helper function to get color
def get_color(color_name):
    colors = {
        'red': (255, 0, 0),
        'green': (0, 255, 0),
        'blue': (0, 0, 255),
        'yellow': (255, 255, 0),
    }
    return colors.get(color_name, (255, 255, 255))

# Helper function to check if a card can be played
def can_play_card(card, top_card):
    return card['color'] == top_card['color'] or card['value'] == top_card['value']

# Handle special cards
def handle_special_card(card):
    if card['value'] == 'reverse':
        game_state['players'].reverse()
    elif card['value'] == 'skip':
        game_state['current_player'] = (game_state['current_player'] + 1) % 4
    elif card['value'] == 'draw two':
        next_player = (game_state['current_player'] + 1) % 4
        for _ in range(2):
            game_state['players'][next_player]['hand'].append(game_state['deck'].pop())

# Set up the game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # Handle mouse clicks here
            x, y = pygame.mouse.get_pos()
            current_player = game_state['players'][game_state['current_player']]
            top_card = game_state['discard_pile'][-1]
            
            # Check if the draw pile is clicked
            if 650 <= x <= 750 and 400 <= y <= 450:
                if game_state['deck']:
                    current_player['hand'].append(game_state['deck'].pop())
                    game_state['current_player'] = (game_state['current_player'] + 1) % 4
            
            # Play a card
            hand_x_start = 100
            hand_y_start = 500
            card_width = 50
            card_height = 100
            for index, card in enumerate(current_player['hand']):
                card_x = hand_x_start + index * (card_width + 10)
                card_y = hand_y_start
                if card_x <= x <= card_x + card_width and card_y <= y <= card_y + card_height:
                    if can_play_card(card, top_card):
                        game_state['discard_pile'].append(current_player['hand'].pop(index))
                        handle_special_card(card)
                        if len(current_player['hand']) == 0:
                            print(f"{current_player['name']} wins!")
                            running = False
                        game_state['current_player'] = (game_state['current_player'] + 1) % 4
                    break

    # Draw the game state
    screen.fill((0, 128, 0))  # Green background
    
    # Draw the discard pile on the right side
    if game_state['discard_pile']:
        top_card = game_state['discard_pile'][-1]
        card_color = get_color(top_card['color'])
        pygame.draw.rect(screen, card_color, (650, 250, 100, 150))
        draw_text(f"{top_card['color']} {top_card['value']}", 655, 300, 24, (0, 0, 0))
    
    # Draw the draw deck beneath the discard pile
    pygame.draw.rect(screen, (255, 255, 255), (650, 400, 100, 50))
    draw_text("Draw", 675, 410, 24, (0, 0, 0))
    
    # Draw the players' hands
    hand_x_start = 100
    hand_y_start = 500
    card_width = 50
    card_height = 100
    for index, card in enumerate(game_state['players'][game_state['current_player']]['hand']):
        card_x = hand_x_start + index * (card_width + 10)
        card_y = hand_y_start
        card_color = get_color(card['color'])
        pygame.draw.rect(screen, card_color, (card_x, card_y, card_width, card_height))
        draw_text(f"{card['value']}", card_x + 10, card_y + 40, 24, (0, 0, 0))
    
    # Draw other players' hands (as hidden cards)
    for i, player in enumerate(game_state['players']):
        if i != game_state['current_player']:
            for j in range(len(player['hand'])):
                pygame.draw.rect(screen, (200, 200, 200), (hand_x_start + j * (card_width + 10), 50 + i * 120, card_width, card_height))
    
    # Draw player labels
    for i, player in enumerate(game_state['players']):
        if i == game_state['current_player']:
            color = (255, 0, 0)  # Red for the current player
        else:
            color = (255, 255, 255)  # White for other players
        draw_text(player['name'], 10, 50 + i * 120, 36, color)
    
    pygame.display.flip()

pygame.quit()
