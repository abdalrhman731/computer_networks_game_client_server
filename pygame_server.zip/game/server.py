import socket
import threading
import random
import json

# Define Uno game constants
COLORS = ['red', 'green', 'blue', 'yellow']
VALUES = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'reverse', 'skip', 'draw two']

# Global variables for game state and player count
game_state = None
num_players = 0
clients = []

# Function to handle client connections
def handle_client(client_socket, player_id):
    global game_state
    global clients

    # Send initial game state to the client
    send_data(client_socket, {"player_id": player_id, "game_state": game_state})

    # Handle receiving data from the client
    while True:
        try:
            data = receive_data(client_socket)
            if not data:
                break
            # Handle received data
            received_data = json.loads(data)
            print(f"Received data from Player {player_id}: {received_data}")
            # Update game state and notify other clients
            update_game_state(received_data)
            broadcast_game_state()
        except Exception as e:
            print(f"Error: {e}")
            break
    client_socket.close()
    clients.remove(client_socket)

# Function to send data to a client
def send_data(client_socket, data):
    try:
        json_data = json.dumps(data)
        length = len(json_data)
        client_socket.sendall(length.to_bytes(4, 'big') + json_data.encode())
    except Exception as e:
        print(f"Error sending data: {e}")

# Function to receive data from a client
def receive_data(client_socket):
    try:
        raw_length = client_socket.recv(4)
        if not raw_length:
            return None
        length = int.from_bytes(raw_length, 'big')
        data = client_socket.recv(length)
        while len(data) < length:
            data += client_socket.recv(length - len(data))
        return data.decode()
    except Exception as e:
        print(f"Error receiving data: {e}")
        return None

# Function to broadcast the game state to all clients
def broadcast_game_state():
    global clients
    for client in clients:
        send_data(client, {"game_state": game_state})

# Function to create a new game state
def create_game_state():
    deck = [{'color': color, 'value': value} for color in COLORS for value in VALUES]
    random.shuffle(deck)
    players = [{'name': f'Player {i+1}', 'hand': []} for i in range(num_players)]
    for player in players:
        for _ in range(7):
            player['hand'].append(deck.pop())
    discard_pile = [deck.pop()]
    return {'deck': deck, 'players': players, 'discard_pile': discard_pile, 'current_player': 0}

# Function to update the game state
def update_game_state(received_data):
    global game_state
    game_state = received_data['game_state']

# Server function
def start_server():
    global num_players
    global game_state
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 12345))
    server_socket.listen(4)  # Maximum of 4 players

    while True:
        client_socket, addr = server_socket.accept()
        if num_players < 4:
            print(f"Connection from {addr} has been established!")
            clients.append(client_socket)
            num_players += 1
            if num_players >= 2 and game_state is None:  # Start the game when at least 2 players are connected
                game_state = create_game_state()
                broadcast_game_state()
            threading.Thread(target=handle_client, args=(client_socket, num_players)).start()
        else:
            print("Connection rejected: Maximum number of players reached.")
            client_socket.close()

# Start the server
start_server()
